document.addEventListener('DOMContentLoaded', () => {
  // 添加文件按钮
  const addFileBtn = document.getElementById('addFileBtn');
  const fileForm = document.getElementById('fileForm');
  const cancelForm = document.getElementById('cancelForm');
  const fileFormContent = document.getElementById('fileFormContent');
  
  if (addFileBtn) {
    addFileBtn.addEventListener('click', () => {
      fileForm.style.display = 'flex';
      // 重置表单
      fileFormContent.reset();
      // 设置表单为添加模式
      fileFormContent.dataset.mode = 'add';
      fileFormContent.querySelector('h3').textContent = '添加新文件';
    });
  }
  
  if (cancelForm) {
    cancelForm.addEventListener('click', () => {
      fileForm.style.display = 'none';
    });
  }
  
  // 编辑按钮
  const editButtons = document.querySelectorAll('.edit-btn');
  editButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const fileId = btn.dataset.id;
      const fileCard = btn.closest('.file-card');
      const fileName = fileCard.querySelector('h3').textContent;
      
      // 获取所有链接
      const links = Array.from(fileCard.querySelectorAll('.links a'))
        .map(a => a.href)
        .join('\n');
      
      // 填充表单
      document.getElementById('fileName').value = fileName;
      document.getElementById('fileLinks').value = links;
      
      // 设置表单为编辑模式
      fileFormContent.dataset.mode = 'edit';
      fileFormContent.dataset.id = fileId;
      fileFormContent.querySelector('h3').textContent = '编辑文件';
      
      fileForm.style.display = 'flex';
    });
  });
  
  // 表单提交
  if (fileFormContent) {
    fileFormContent.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const formData = new FormData(fileFormContent);
      const name = formData.get('name');
      const links = formData.get('links');
      
      if (!name || !links) {
        alert('请填写所有必填字段');
        return;
      }
      
      const mode = fileFormContent.dataset.mode;
      const fileId = fileFormContent.dataset.id;
      
      let url = '/add-file';
      if (mode === 'edit') {
        url = `/update-file/${fileId}`;
      }
      
      fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, links })
      })
      .then(response => {
        if (response.redirected) {
          window.location.href = response.url;
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('操作失败，请重试');
      });
    });
  }
});